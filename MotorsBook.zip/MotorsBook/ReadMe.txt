This archive contains the sketches for the book "Controlling Motors with Arduino/Genuino." The file names are in the format S#P#, which stands for Sketch # Point #. For example, sketch 2.1 in the book has the file name S2P1.

Copy or move the MotorsBook folder to your Documents/Arduino folder and it should show up in Sketchbook under the Arduino File menu. You may need to shut down and restart the IDE if it was running when you added the Motors folder to the Documents/Arduino folder.

The sketches and other information in this book is available under the MIT license. This license gives you the right to use the information in this book for any legal purpose you like, provided you do not hold the author liable for any damages or problems caused by your use or misuse of the material in this book.
